# peticoesTJSP

Baixa petições iniciais de um processo do TJSP.
