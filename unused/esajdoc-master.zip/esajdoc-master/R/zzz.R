globalVariables(c(
  ".", "id_foro", "value"
))
